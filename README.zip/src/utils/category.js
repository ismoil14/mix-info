import technics from "../assets/imgs/technics.png";
import furniture from "../assets/imgs/furniture.png";
import toys from "../assets/imgs/toys.png";

export const Category = [
  { id: 1, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 2, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 3, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 4, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 5, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 6, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 7, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 8, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 9, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 10, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 11, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 12, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 13, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 14, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 15, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 16, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 17, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 18, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 19, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 20, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 21, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
  { id: 22, name_ru: "Technics", name_uz: "technics", name_en: "Technics", image: `${technics}` },
  { id: 23, name_ru: "Technics", name_uz: "technics", name_en: "Furniture", image: `${furniture}` },
  { id: 24, name_ru: "Technics", name_uz: "technics", name_en: "Toys", image: `${toys}` },
];


